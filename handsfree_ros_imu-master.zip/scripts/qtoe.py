#! /usr/bin/env python3
import numpy as np
#from numpy import quaternion as quat
import rospy
from sensor_msgs.msg import Imu
from std_msgs.msg import Float32MultiArray

def state_cb(msg):
    global current_data
    global rec_array
    global rec_angle
    global rotated_q
    global fix
    global anglex
    global angley
    global anglez
    global fix_q
    global angle
    current_data = msg
    rec_array[0] = msg.orientation.w
    rec_array[1] = msg.orientation.x
    rec_array[2] = msg.orientation.y
    rec_array[3] = msg.orientation.z
    fix -= 1
    if fix > 0 & fix < 6:
        angle = quaternion_to_euler_angle(rec_array)
        anglex += angle[0]
        angley += angle[1]
        anglez += angle[2]
    else:
        rec_angle = quaternion_to_euler_angle(rec_array)
        rec_anglex = rec_angle[0] - angle[0]
        rec_angley = rec_angle[1] - angle[1]
        rec_anglez = rec_angle[2] - angle[2]
        fix_q = euler_to_quaternion(rec_anglex, rec_angley, rec_anglez)
    #Imu_q = quat(rec_array[0], rec_array[1], rec_array[2], rec_array[3])
    #rotation_axis = np.array([1, 0, 0])  # x軸
    #rotation_angle = np.pi  # 180度，以弧度表示
    #rotation_quaternion = quat(np.cos(rotation_angle / 2), np.sin(rotation_angle / 2) * rotation_axis[0], 
    #                           np.sin(rotation_angle / 2) * rotation_axis[1], 
    #                           np.sin(rotation_angle / 2) * rotation_axis[2])
    #rotated_q = rotation_quaternion.conjugate() * Imu_q * rotation_quaternion

def quaternion_to_euler_angle(quaternion):
    """
    Convert quaternion to Euler angles (roll, pitch, yaw).
    :param quaternion: A numpy array representing the quaternion [w, x, y, z].
    :return: A numpy array representing the Euler angles [roll, pitch, yaw] in degrees.
    """
    # Extract components
    w, x, y, z = quaternion

    # Calculate roll (x-axis rotation)
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll_x = np.degrees(np.arctan2(t0, t1))

    # Calculate pitch (y-axis rotation)
    t2 = +2.0 * (w * y - z * x)
    t2 = np.where(t2 > 1.0, 1.0, t2)
    t2 = np.where(t2 < -1.0, -1.0, t2)
    pitch_y = np.degrees(np.arcsin(t2))

    # Calculate yaw (z-axis rotation)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw_z = np.degrees(np.arctan2(t3, t4))

    # Return Euler angles in degrees
    return np.array([roll_x, pitch_y, yaw_z])

def euler_to_quaternion(roll, pitch, yaw):
    
    yaw = np.radians(yaw)
    pitch = np.radians(pitch)
    roll = np.radians(roll)

    cy = np.cos(yaw * 0.5)
    sy = np.sin(yaw * 0.5)
    cp = np.cos(pitch * 0.5)
    sp = np.sin(pitch * 0.5)
    cr = np.cos(roll * 0.5)
    sr = np.sin(roll * 0.5)

   
    qw = cy * cp * cr + sy * sp * sr
    qx = cy * cp * sr - sy * sp * cr
    qy = sy * cp * sr + cy * sp * cr
    qz = sy * cp * cr - cy * sp * sr

    return np.array([qw, qx, qy, qz])

if __name__ == "__main__":
    rospy.init_node("qtoe.py")
    fix_q = [0, 0, 0, 0]
    fix = 10
    angle = [0, 0, 0]
    anglex = 0
    angley = 0
    anglez = 0
    rec_angle = [0, 0, 0]
    current_data = Imu() 
    imu_sub = rospy.Subscriber("handsfree/imu", Imu, callback = state_cb)
    rec_array = [0, 0, 0, 0]   

    imu_pub = rospy.Publisher("fixed_q", Float32MultiArray, queue_size = 20)
    rate = rospy.Rate(10)
    

    while (not rospy.is_shutdown()):
        rospy.loginfo("Publish!")
        send_data = Float32MultiArray()
        send_data.data = fix_q
        imu_pub.publish(send_data)
        
        rospy.loginfo(quaternion_to_euler_angle(fix_q))
        rate.sleep()

